import React from 'react';
import AuthForm from '../../components/AuthForm/AuthForm';

const LoginPage: React.FC = () => <AuthForm />;

export default LoginPage;

